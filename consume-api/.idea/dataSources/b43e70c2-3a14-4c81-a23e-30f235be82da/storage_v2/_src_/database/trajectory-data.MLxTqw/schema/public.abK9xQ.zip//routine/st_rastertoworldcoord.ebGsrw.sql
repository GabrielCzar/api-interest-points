CREATE FUNCTION st_rastertoworldcoord(rast raster, columnx integer, rowy integer, OUT longitude double precision, OUT latitude double precision)
  RETURNS record
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT longitude, latitude FROM public._ST_rastertoworldcoord($1, $2, $3)
$$;

