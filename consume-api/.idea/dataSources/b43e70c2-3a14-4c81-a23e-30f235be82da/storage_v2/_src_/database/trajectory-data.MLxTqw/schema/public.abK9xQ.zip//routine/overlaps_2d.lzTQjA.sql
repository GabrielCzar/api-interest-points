CREATE FUNCTION overlaps_2d(geometry, box2df)
  RETURNS boolean
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.&&) $1;
$$;

