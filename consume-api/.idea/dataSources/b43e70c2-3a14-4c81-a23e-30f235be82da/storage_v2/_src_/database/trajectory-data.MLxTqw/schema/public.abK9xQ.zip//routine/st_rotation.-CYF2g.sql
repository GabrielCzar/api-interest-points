CREATE FUNCTION st_rotation(raster)
  RETURNS double precision
LANGUAGE SQL
AS $$
SELECT ( public.ST_Geotransform($1)).theta_i
$$;

