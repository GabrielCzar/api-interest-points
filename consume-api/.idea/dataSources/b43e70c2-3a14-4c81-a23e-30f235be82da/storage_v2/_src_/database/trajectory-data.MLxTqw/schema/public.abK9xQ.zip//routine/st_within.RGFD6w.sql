CREATE FUNCTION st_within(geom1 geometry, geom2 geometry)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT $2 OPERATOR(public.~) $1 AND public._ST_Contains($2,$1)
$$;

