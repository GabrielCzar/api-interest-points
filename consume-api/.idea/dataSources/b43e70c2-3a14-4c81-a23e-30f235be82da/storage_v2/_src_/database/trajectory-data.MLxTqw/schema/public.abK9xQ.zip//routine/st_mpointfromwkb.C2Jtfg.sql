CREATE FUNCTION st_mpointfromwkb(bytea)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1)) = 'MULTIPOINT'
	THEN public.ST_GeomFromWKB($1)
	ELSE NULL END

$$;

