CREATE FUNCTION st_isvalid(geometry, integer)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT (public.ST_isValidDetail($1, $2)).valid
$$;

