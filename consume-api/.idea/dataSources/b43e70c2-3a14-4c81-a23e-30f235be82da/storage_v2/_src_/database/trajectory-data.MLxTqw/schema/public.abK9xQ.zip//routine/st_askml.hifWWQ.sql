CREATE FUNCTION st_askml(text)
  RETURNS text
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_AsKML(2, $1::public.geometry, 15, null);
$$;

