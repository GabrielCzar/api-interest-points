CREATE FUNCTION st_centroid(text)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT ST_Centroid($1::public.geometry);
$$;

