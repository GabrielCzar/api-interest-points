CREATE FUNCTION st_worldtorastercoordy(rast raster, xw double precision, yw double precision)
  RETURNS integer
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT rowy FROM public._ST_worldtorastercoord($1, $2, $3)
$$;

