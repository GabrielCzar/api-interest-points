CREATE FUNCTION st_buffer(text, double precision, text)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT ST_Buffer($1::public.geometry, $2, $3);
$$;

