CREATE FUNCTION raster_above(raster, raster)
  RETURNS boolean
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
select $1::geometry |>> $2::geometry
$$;

