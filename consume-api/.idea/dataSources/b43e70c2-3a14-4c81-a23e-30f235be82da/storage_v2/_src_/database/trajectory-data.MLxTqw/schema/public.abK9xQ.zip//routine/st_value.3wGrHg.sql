CREATE FUNCTION st_value(rast raster, pt geometry, exclude_nodata_value boolean DEFAULT true)
  RETURNS double precision
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_value($1, 1, $2, $3)
$$;

