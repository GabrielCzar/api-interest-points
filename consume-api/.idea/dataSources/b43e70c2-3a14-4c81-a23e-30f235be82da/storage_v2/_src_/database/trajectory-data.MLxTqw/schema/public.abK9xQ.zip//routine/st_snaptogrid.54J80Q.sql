CREATE FUNCTION st_snaptogrid(rast raster, gridx double precision, gridy double precision, algorithm text DEFAULT 'NearestNeighbour'::text, maxerr double precision DEFAULT 0.125, scalex double precision DEFAULT 0, scaley double precision DEFAULT 0)
  RETURNS raster
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public._ST_GdalWarp($1, $4, $5, NULL, $6, $7, $2, $3)
$$;

