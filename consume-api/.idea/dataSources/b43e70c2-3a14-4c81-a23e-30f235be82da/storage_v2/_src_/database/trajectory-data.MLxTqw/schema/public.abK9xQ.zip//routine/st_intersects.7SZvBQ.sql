CREATE FUNCTION st_intersects(text, text)
  RETURNS boolean
IMMUTABLE
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT ST_Intersects($1::public.geometry, $2::public.geometry);
$$;

