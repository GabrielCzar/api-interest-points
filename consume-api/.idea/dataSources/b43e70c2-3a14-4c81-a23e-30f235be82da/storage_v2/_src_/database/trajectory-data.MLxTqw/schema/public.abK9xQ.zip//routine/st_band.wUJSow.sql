CREATE FUNCTION st_band(rast raster, nband integer)
  RETURNS raster
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT  public.ST_band($1, ARRAY[$2])
$$;

