CREATE FUNCTION st_dfullywithin(geom1 geometry, geom2 geometry, double precision)
  RETURNS boolean
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT $1 OPERATOR(public.&&) public.ST_Expand($2,$3) AND $2 OPERATOR(public.&&) public.ST_Expand($1,$3) AND public._ST_DFullyWithin(public.ST_ConvexHull($1), public.ST_ConvexHull($2), $3)
$$;

