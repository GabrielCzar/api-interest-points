CREATE FUNCTION st_forcepolygonccw(geometry)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
COST 15
LANGUAGE SQL
AS $$
SELECT public.ST_Reverse(public.ST_ForcePolygonCW($1))
$$;

