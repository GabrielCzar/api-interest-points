CREATE FUNCTION st_buffer(text, double precision)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT ST_Buffer($1::public.geometry, $2);
$$;

