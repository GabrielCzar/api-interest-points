CREATE FUNCTION st_geomfromwkb(bytea, integer)
  RETURNS geometry
IMMUTABLE
STRICT
PARALLEL SAFE
LANGUAGE SQL
AS $$
SELECT public.ST_SetSRID(public.ST_GeomFromWKB($1), $2)
$$;

